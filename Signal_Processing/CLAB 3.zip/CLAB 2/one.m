clc
clf

w=linspace(-2*pi,2*pi,500); 

h1= 1 + 2*cos(3*w);
h2=  j*cos(w) 
hold on
subplot(2,1,1)

plot(w,abs(h1))

subplot(2,1,2)
plot(w,imag(h2))