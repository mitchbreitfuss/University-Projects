
clf
clear
N=12;

n = 0:1:(2*N-1);
int=0:1:100;

M_array= [4,5,7,10];

x_array=[];
temp=[0,0,0,0]
M=0
hold on
axis([-2*pi 2*pi -2 2])

for i = 1:4;
    
    M=M_array(i)
    x = sin((2*pi*M*n)/N);
    
    x_array = [x_array x];
    
    
    subplot(4,1,i)
    stem(n,x)
    
    temp(i) = (2*pi)/((2*M*pi)/N)
    
    
    
    
    
    i=i+1
end


j=1;

for i=1:4
   k=0;
    
    while k <100
    k=k+1;
 
        if floor(temp(i)*k) ==temp(i)*k;
        period(i) = temp(i)*k;
        break
    
        else
            floor(temp(i)*k) ==temp(i)*k;
            
        
        
        
        
        
        end
    end
end
    period
    
    

