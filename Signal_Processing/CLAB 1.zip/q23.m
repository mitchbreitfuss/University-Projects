clf
clear
k=[1,2,4,6]

x_array=[]

n=0:0.1:9
hold on

for i = 1:length(k)
    
    omega = 2*pi*k(i)/5
    
   



    x=sin(omega*n)
    
    x_array=[x_array x]
    
    subplot(4,1,i)
    stem(n,x)
    
end
    
% I Obtained 3 unique plots. This is because plot 1 and 4 are the same
% signal, but with different periods. Due to constraints in using DT time,
% they have the same fundamental period.