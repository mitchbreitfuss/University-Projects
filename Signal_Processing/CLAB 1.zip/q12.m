clf
tinc = 0.01;
t = -3:tinc:3;
f = exp(-t).*cos(2*pi*t).*heaviside(t);
subplot(5,1,1)
plot(t,f);
xlabel('time, t (seconds)');
ylabel('f(t)');

hold on

subplot(5,1,2)

t2=-t
plot(t,exp(-t2).*cos(2*pi*t2).*heaviside(t2));
subplot(5,1,3)

t3=-3*t
plot(t,exp(-t3).*cos(2*pi*t3).*heaviside(t3))
subplot(5,1,4)

t4=-t/3
plot(t,exp(-t4).*cos(2*pi*t4).*heaviside(t4))
subplot(5,1,5)

t5=3*t-1
t=t-1
plot(t,exp(-t5).*cos(2*pi*t5).*heaviside(t5))