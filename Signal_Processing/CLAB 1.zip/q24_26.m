clear
clf


n=0:1:31;





x1 = sin(pi*n/4).*cos(pi*n/4);
x2 = (cos(pi*n/4)).^2;
x3 = sin(pi*n/4).*cos(pi*n/8);
hold on

subplot(3,1,1);
stem(n,x1);
subplot(3,1,2);
stem(n,x2);
subplot(3,1,3);
stem(n,x3);

period = [4,4,16]

%The Fundamental period of the two with the same argument was half that of
%the two individual functions. The fundamental period of the 3rd curve did
%not follow this trend.
        