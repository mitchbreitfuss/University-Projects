n=0:20



%y=(1/2).^n * 2.*(((3/4).^(n+1)).*2.^(n+1) - 1)

% for i=1:length(n)
% 
% y(i)=(1/2)^
% 
% 
% 
% 
% end
hold on
subplot(2,1,1)
stem(n,y)
subplot(2,1,2)
y2=3*(3/4).^n - 2*(1/2).^n
stem(n,y2)


