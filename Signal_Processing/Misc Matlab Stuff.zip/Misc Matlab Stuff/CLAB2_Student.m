clc; clear all; close all;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Student Name: Mitchell Breitufss
% Student ID: u6043905
% Student Group: Thursday 1PM

% Student Name:
% Student ID:
% Student Group:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Global Control/Display Parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
plotON = 1;                         % Set plotON = 1 to display plots
playON = 0;                         % Set playON = 1 to show animation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                 TASK 1
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 1-1: ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% In this task, we first understand the following Matlab code which draws
% the time domain waveform and the Fourier coecients for the above Periodic
% Rectangular Wave with T = 8 and T1 = 1. Learn how to use "drawFourierSeries.m"
% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
T      = 4;                         % fundamental period
tmax   = 10;                        % define time limit
T1     = 1;                         % half-width of pulse
K      = 2;                        % number of fourier series coefficients

drawFourierSeries(T,T1,tmax,K,plotON,playON)
waitforbuttonpress

% % 1-2: ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% In the given code, the maximum number of Fourier series coecients K = 50 
% have been considered. Use K = 5, 10 and 20 and observe the difference in 
% the plot of the signal in time domain. Record your observation and explain
% it in the space below
% BRIEF ANSWER: ###########################################################
% As k is increased, the Fourier series becomes more and more like a square
% pulse wave.
%
% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                TASK 2
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 2-1: ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% For a signal x(t) in Task 1, use time shift property to plot the signal 
% x(t-2) and x(t-5) by modifying the Fourier series coeffcients in the
% function "TimeShiftFourierSeries.m" (Hint: study the time-shift property
% and read the description at the top of the "TimeShiftFourierSeries.m").
% Make sure that the output is as you expect, show it to the tutor, and then
% record your observation in the space below

t0 = 2;                        % time shift for x(t-2)
[x2,~] = TimeShiftFourierSeries(t0,T,T1,K,tmax,plotON);

t0 = 5;                        % time shift for x(t-5)
[x5,~] = TimeShiftFourierSeries(t0,T,T1,K,tmax,plotON);


% BRIEF ANSWER: ###########################################################
%
%By multiplying the cooefficient (of form e^(j*omega0*k*t)) by
%e^(-j*omega0*k*t0), it results in e^(j*omega0*k*(t-t0)) - thus time shifts
%the signal
%
%##########################################################################
% 2-2 AND 2-3: ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% Determine the Fourier coefficients of the periodic stepped wave shown in 
% page 3 of the lab script and generate a similar waveform. To do this, you 
% will use the linearity property of Fourier Series and utilize the signal
% shown in page 2 of your lab script and eqn(1) and follow the steps below:

% [1] Read the description at the top of the "FourierSeries.m" and learn how
% to use it.

% [2] Generate 4 periodic rectangular signals, x1(t), x2(t), x3(t) and
% x4(t) with amplitudes a, b, c, and d respectively. Select a, b, c, and d
% to be last rightmost digits of your ANU id (e.g. u614abcd).

% [3] Select appropriate time-shift for each of the four signals.

% [4] Determine the value of T1 that is suitable for all of these signals,
% and select the period of the signals T=8.

% [5] Generate X(t)=x1(t)+x2(t)+x3(t)+x4(t). Following time-shift property,
% the Forier Series coeffecients of X(t) will be the sum of the Fourier
% Series coffecients of x1(t), x2(t), x3(t) and x4(t). 

% [6] Plot X(t) and stem the Fourier Series coeffecients.

% ~~~~~~~~~~~~~~~~~~~~~~~~ WRITE YOUR CODE HERE: ~~~~~~~~~~~~~~~~~~~~~~~~~~
T  = 8; 
T1 = 1;

% FORMAT:
a= 6
b= 0
c= 4
d= 3


[x1,a1] = FourierSeries(a,0,T,T1,K,tmax,plotON)
[x2,a2] = FourierSeries(b,2,T,T1,K,tmax,plotON)
[x3,a3] = FourierSeries(c,4,T,T1,K,tmax,plotON)
[x4,a4] = FourierSeries(d,6,T,T1,K,tmax,plotON)

% sum of the signals
Xt = x1+x2+x3+x4;   

% sum of the coeffecients
ak = a1+a2+a3+a4;

if (plotON==1)
    figure;
    subplot(2,1,1); stem([-K:K],real(ak),'b','LineWidth',1.5); 
                    title(strcat('Fourier Series Coeffecients'));
                    xlim([-max(K),max(K)]); xlabel('k'); grid on;
                    legend('X(t) Fourier Series Coeffecients');
    
    subplot(2,1,2); plot([-tmax:0.01:tmax],real(Xt),'b','LineWidth',1.5);
                    title('X(t)'); xlim([-tmax,tmax]); grid on;
                    xlabel('Time'); ylabel('Amplitude');
                    legend('X(t)');
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                 TASK 3
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 3-1:~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% Run the provided 'drawFourierSeries.m' function with the following values
% of T and T1 below (note that the ratio 2*T1/T, which is known as the duty
% cycle is constant). Is there any difference in plots both in time and/or 
% Fourier(frequency) domain. Write your answer in the space below.

T  = 4;
T1 = 1;
drawFourierSeries(T,T1,tmax,K,plotON,playON);

T  = 6;
T1 = 1.5;
drawFourierSeries(T,T1,tmax,K,plotON,playON);

T  = 8;
T1 = 2;
drawFourierSeries(T,T1,tmax,K,plotON,playON);

% BRIEF ANSWER: ###########################################################
%There is a change in the time domain of frequency and pulse width, which
%is affected by the period T, and T1 respectively.
%There is no change in the frequency domain, as the cooefficients are the
%same due to the duty cycle ratio remaining at 1/2, regardless of T1. 
%(2*1/4 = 1/2, 2*1.5/6 = 1/2, 2*2/8=1/2)
%
%##########################################################################
% 3-2:~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% In above exercises, duty cycle (2T1/T) has been kept constant. Now we see
% the effect of changing the duty cycle on Fourier series. Repeat the Matlab
% excercise 3-1 for T = 8 and T1 = 1, 1.5 and 2. Is there any difference in
% the plots of the time and/or Fourier(frequency) domain? Write your answer
% in the space below.

T  = 8;
T1 = 1;
drawFourierSeries(T,T1,tmax,K,plotON,playON);

T  = 8;
T1 = 1.5;
drawFourierSeries(T,T1,tmax,K,plotON,playON);

T  = 8;
T1 = 2;
drawFourierSeries(T,T1,tmax,K,plotON,playON);
% BRIEF ANSWER: ###########################################################
% There is no change in period in the time domain between plots, although
% the pulse width does change.
%
% There is a difference in the frequency domain, as the duty cycle ratio
% changes for each value of T1 due to T = 8 being constant.
%
%##########################################################################
% 3-3:~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% Explain your observations here and write your conlusions here.
% BRIEF ANSWER: ###########################################################
%
%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                 TASK 4
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 4-1:~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% What is the fundamental period T for the signal below? Analytically find 
% the Fourier coefficients of x1(t).

t      = linspace(-1,1,1000);
omega0 = 2*pi;
x1     = cos(omega0*t) + sin(2*omega0*t);

if (plotON==1)
    figure; plot(t,x1,'b','LineWidth',1.5); grid on;
    xlabel('t'); ylabel('Amplitude'); legend('x_1(t)')
end

% BRIEF ANSWER: ###########################################################
% The fundamental period T = 1
% a1=a-1, = 1/2
% a2 = a-2, = 1/2j
%
%##########################################################################
% 4-2:~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% Using the time-reversal and linearity properties, find the coefficients of
% y(t) = x1(t) + x1(-t).
% 
% y(t)=x(t)+x(-t)=2cos(omega0*t)
% Coefficients: a1=a-1, = 1 
% 
% 4-3:~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% Plot y(t). What type of symmetry do you observe? Explain the reason.

y      = 2*cos(omega0*t);

if(plotON==1)
    figure; plot(t,y,'b','LineWidth',1.5); grid on;
    xlabel('t'); ylabel('Amplitude'); legend('y(t)')
end
% BRIEF ANSWER: ###########################################################
% It is symmetric about the y axis as it is simply a cos() function.
% This is due to x1(t) + x1(-t) cancelling out the sin() part of the
% function. (The odd part of the function cancells out to zero.
%
%
%##########################################################################
% 4-4:~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% Using the time-reversal, linearity and conjugation properties find the 
% coefficients of z(t) = x1(t)+ conj(x1(-t)).
% 
% The coefficients are exactly the same as for part 4-2, due to the signal
% x(t) not having any imaginary part. (Conj does nothing)
%
% y(t)=x(t)+x(-t)=2cos(omega0*t)
% Coefficients: a1=a-1, = 1
% 
% 4-5:~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% Plot z(t). What type of symmetry do you observe? Explain the reason.

z      = 2*cos(omega0*t);

if (plotON==1)
    figure; plot(t,z,'b','LineWidth',1.5); grid on;
    xlabel('t'); ylabel('Amplitude'); legend('z(t)')
end
% BRIEF ANSWER: ###########################################################
%
% As with part 4-3, it is symmetric about the y axis due to it being a
% non-time shifted cos wave.
%
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% That is the end of CLAB2. Before leaving the lab, please send your matlab
% file to:
%                       ehab.salahat@anu.edu.au
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%