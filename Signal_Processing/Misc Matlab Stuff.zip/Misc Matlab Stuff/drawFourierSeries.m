%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function drawFourierSeries(T,T1,tmax,K,plotON,playON)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
omega0 = pi/2;                   % fundamental frequency (radians/sec)
t      = [-tmax:0.01:tmax];        % define points along time axis

if playON==1
    END   = K;
    K     = [1:K];
else
    END   = 1;
end
strng = max(K);

if (plotON==1)||(playON==1)
    figure;
end

for ii=1:1:END
    k          = [-K(ii):K(ii)];   % max number of Fourier Series Coefficients
    k(K(ii)+1) = 0.0001;           % lazy way to deal with 0/0 limit
    
    % compute the Fourier Series Coefficients of the rectangular waveform
    % matlab is a matrix/vector language. k is a vector and k*omega0*T1 is a scaled version
    % of k; The denominator is a vector, doing a ./ division is an element-wise division.
    
    a          = sin(k*omega0*T1)./(k*pi)
    k(K(ii)+1) = 0;                % cover our deception dealing with 0/0 limit

    waveform   = a*exp(1i*omega0*k'*t);
    % Plotting ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    if (plotON==1)||(playON==1)
        if (playON==1)
            strng = ii;
        end
        message = strcat('T=',num2str(T),', T_1=',num2str(T1),', K=',num2str(K(ii)));
        subplot(2,1,1); stem(k, real(a),'b','LineWidth',1.5); grid on;
        title(message);
        axis([-max(K),max(K),-0.1,0.6]); xlabel('k')
        
        subplot(2,1,2);
        plot(t,real(waveform),'b','LineWidth',1.5);  title(message);
        axis([-tmax,tmax,-0.3,1.2]); xlabel('Time'); ylabel('Amplitude'); grid on;
        pause(0.05);
    end
    %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
end