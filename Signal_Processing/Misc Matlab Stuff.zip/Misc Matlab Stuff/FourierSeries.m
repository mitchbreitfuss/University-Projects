%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [x2,a2] = FourierSeries(A,t0,T,T1,K,tmax,plotON)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Descrption: ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% x2 is the time-shifted (by t0) and scaled (by A) rectangular pulse (in the
% time domain) with width T1 and fundamental period T. The associated Fourier
% Series Coeefecients are stored in a2.
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
omega0   = pi/2;              % fundamental frequency (radians/sec)
t        = [-tmax:0.01:tmax];   % define points along time axis
k        = [-K:K];              % max number of Fourier Series Coefficients
k(K+1)   = 0.0001;
a1       = sin(k.*omega0.*T1)./(k.*pi);
k(K+1)   = 0;

a2       = a1.*exp(-1i.*omega0.*k.*t0);
x2       = A.*a2*exp(1i*omega0*k'*t);
% Plotting ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
if (plotON==1)
    figure;
    message = strcat('T=',num2str(T),', T_1=',num2str(T1),', Amplitude=',num2str(A),', t_0=',num2str(t0),', K=',num2str(K));
    subplot(2,1,1); stem(k,real(a2),'b','LineWidth',1.5); grid on;
                    title(message);
                    xlim([-max(K),max(K)]); xlabel('k')
    
    subplot(2,1,2); plot(t,real(x2),'b','LineWidth',1.5);
                    title(message);
                    xlim([-tmax,tmax]); grid on;
                    xlabel('Time'); ylabel('Amplitude');
end
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~